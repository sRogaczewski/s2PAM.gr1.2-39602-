Sample applications available at https://github.com/visioforge/.Net-SDK-s-samples .

Please restart Visual Studio to finish package installation.