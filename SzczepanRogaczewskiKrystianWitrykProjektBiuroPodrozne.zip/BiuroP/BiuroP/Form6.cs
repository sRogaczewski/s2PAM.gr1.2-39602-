﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace BiuroP
{
    public partial class Form6 : Form
    {
        static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=biuro_podrozne;";
        MySqlConnection databaseConnection = new MySqlConnection(connectionString);

        public Form6()
        {
            InitializeComponent();
        }

        private void button_dodaj_kont_Click(object sender, EventArgs e)
        {
            if (isNotEmpty() == true)
            {
                string insertQuery = "INSERT INTO biuro_podrozne.klienci(haslo,Imie,Nazwisko,Pesel,Miasto,Ulica,Numer_telefonu,Mail) VALUES('" + CreateMD5(Hasło.Text) + "','" + Imie.Text + "','" + Nazwisko.Text + "','" + Pesel.Text + "','" + Miasto.Text + "','" + Ulica.Text + "'," + Int32.Parse(Numer_tel.Text) + ",'" + Mail.Text + "')";
                string queryStr = "SELECT *  FROM biuro_podrozne.klienci";
                int idValue = 0;
                databaseConnection.Open();
                MySqlCommand command = new MySqlCommand(insertQuery, databaseConnection);

                MySqlCommand cmd = new MySqlCommand(queryStr, databaseConnection);
                var dr = cmd.ExecuteReader();
  
                if (dr.HasRows)
                {
                    while (dr.Read())

                        idValue = Int32.Parse(dr.GetString(0));


                }
                dr.Close();


                try
                {
                    if (command.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("Zarejestrowano, twoje Id to: " + idValue);
                    }
                    else
                    {
                        
                        MessageBox.Show("Niezarejestrowano");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                databaseConnection.Close();
            }
            else checkTextBox();
        }
        public static string CreateMD5(string input)
        {

            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }
        public void checkTextBox()
        {
            if(Imie.Text=="")MessageBox.Show("Podaj imię");
            if (Nazwisko.Text == "") MessageBox.Show("Podaj Nazwisko");
            if (Pesel.Text == "") MessageBox.Show("Podaj Pesel");
            if (Miasto.Text == "") MessageBox.Show("Podaj Miasto");
            if (Ulica.Text == "") MessageBox.Show("Podaj Ulicę");
            if (Numer_tel.Text == "") MessageBox.Show("Podaj Numer telefonu");
            if (Mail.Text == "") MessageBox.Show("Podaj Mail");
            if (Hasło.Text == "") MessageBox.Show("Podaj Haslo");
        }
        public bool isNotEmpty()
        {
            if (Imie.Text == "") return false;
            if (Nazwisko.Text == "") return false;
            if (Pesel.Text == "") return false;
            if (Miasto.Text == "") return false;
            if (Ulica.Text == "") return false;
            if (Numer_tel.Text == "") return false;
            if (Mail.Text == "") return false;
            if (Hasło.Text == "") return false;

            return true;
        }
    }
}
