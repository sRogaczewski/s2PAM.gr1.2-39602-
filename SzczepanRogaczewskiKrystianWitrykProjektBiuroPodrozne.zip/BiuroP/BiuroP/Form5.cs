﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
namespace BiuroP
{
    
    public partial class Form5 : Form
    {
        static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=biuro_podrozne;";
        MySqlConnection databaseConnection = new MySqlConnection(connectionString);
        MySqlDataAdapter adapter,adapter1;
        DataTable table = new DataTable();
        DataTable table1 = new DataTable();
        public Form5()
        {
            InitializeComponent();
            Form5_Load();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string deleteQuery = "DELETE FROM  biuro_podrozne.wycieczki WHERE Id_wycieczki = " + Id.Text;
                databaseConnection.Open();
                MySqlCommand command = new MySqlCommand(deleteQuery, databaseConnection);

                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Hotel usunięty");
                }
            
                else
                {
                    MessageBox.Show("Hotel nieusunięty");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            databaseConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (isNotEmpty() == true)
            {
                string insertQuery = "INSERT INTO biuro_podrozne.wycieczki(Miejsce,Cena,Opis_wycieczki,Id_przewodnika,Id_hotelu) VALUES('" + Miejsce.Text + "'," + Cena.Text + ",'" + Opis.Text + "',"+  Int16.Parse(Idprzewodnika.Text) + ","+Int16.Parse(Idhotelu.Text)+ ")";

            // string insertQuery = "INSERT INTO biuro_podrozne.wycieczki(Miejsce,Cena,Opis_wycieczki,Id_przewodnika,Id_hotelu) VALUES('" + Miejsce.Text + "'," + Cena.Text + ",'" + Opis.Text + "'," + Idprzewbox.SelectedItem.ToString() + "," + Int16.Parse(Idhotelu.Text) + ")";
            databaseConnection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, databaseConnection);
           
            try
            {
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Wycieczka dodana");
                }
                else
                {
                    MessageBox.Show("Wycieczka niedodana");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            databaseConnection.Close();
        }
            else checkTextBox();
    }

 

        private void Form5_Load()
        {
           adapter = new MySqlDataAdapter("SELECT * FROM biuro_podrozne.hotel", databaseConnection);
            adapter.Fill(table);
            Idhotelbox.DataSource = table;
            Idhotelbox.DisplayMember = "Id_hotelu";
           adapter1 = new MySqlDataAdapter("SELECT * From biuro_podrozne.przewodnicy",databaseConnection);
            adapter1.Fill(table1);
            Idprzewbox.DataSource = table1;
            Idprzewbox.DisplayMember = "Id_przewodnika";
                

        }

        public void checkTextBox()
        {

            if (Miejsce.Text == "") MessageBox.Show("Podaj miejsce wycieczki");
            if (Cena.Text == "") MessageBox.Show("Podaj cenę za osobę");
            if (Opis.Text == "") MessageBox.Show("Podaj opis wycieczki");
            if (Idprzewodnika.Text == "") MessageBox.Show("Podaj id przewodnika");
            if (Idhotelu.Text == "") MessageBox.Show("Podaj id hotelu");
        }
        public bool isNotEmpty()
        {
            if (Miejsce.Text == "") return false;
            if (Cena.Text == "") return false;
            if (Opis.Text == "") return false;
            if (Idprzewodnika.Text == "") return false;
            if (Idhotelu.Text == "") return false;


            return true;
        }
    }
}
