﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BiuroP
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
            RezerwacjeFill();
        }
        static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=biuro_podrozne;";
        MySqlConnection databaseConnection = new MySqlConnection(connectionString);
        MySqlDataReader reader;
        private void RezerwacjeFill()
        {
            string rezerwacjaQuery = "SELECT Id_rezerwacji, Początek,Koniec,Koszt,Liczba_osób  FROM biuro_podrozne.rezerwacja WHERE Id_klienta="+Form1.UserId;
            MySqlCommand commandDatabase = new MySqlCommand(rezerwacjaQuery, databaseConnection);
            try
            {
                databaseConnection.Open();

                reader = commandDatabase.ExecuteReader();

                if (reader.HasRows)
                {


                    while (reader.Read())
                    {
                        string[] row = { reader.GetString(0),reader.GetMySqlDateTime(1).ToString(), reader.GetMySqlDateTime(2).ToString(), reader.GetString(3), reader.GetString(4) };
                        rezerwacjebox.Items.Add(row[0] + "   " + row[1] + "    "+row[2] +"      "+row[3]+"zł             " + row[4] );
                    }
                }
                databaseConnection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string deleteQuery = "DELETE FROM  biuro_podrozne.rezerwacja WHERE Id_rezerwacji= " + Id.Text+ " AND Id_klienta=" + Form1.UserId;
                databaseConnection.Open();
                MySqlCommand command = new MySqlCommand(deleteQuery, databaseConnection);

                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Rezerwacja usunięta");
                }
                else
                {
                    MessageBox.Show("Rezerwacja nieusunięta");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            databaseConnection.Close();
        }
    }
}
