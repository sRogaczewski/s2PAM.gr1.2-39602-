﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BiuroP
{
    
    public partial class Form1 : Form
    {
        public static int UserId = 0;
        static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=biuro_podrozne;";
        MySqlConnection databaseConnection = new MySqlConnection(connectionString);
        MySqlDataReader mdr;
        public Form1()
        {
            InitializeComponent();
            haslopole.PasswordChar = '*';
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2(); //lvl admin
            f.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                string password = "";
                string compareQuery = "Select * FROM biuro_podrozne.klienci WHERE id=" + int.Parse(Idlogin.Text);
                databaseConnection.Open();
                MySqlCommand command = new MySqlCommand(compareQuery, databaseConnection);
                mdr = command.ExecuteReader();
                if (mdr.Read())
                {
                    password = mdr.GetString("haslo");
                }

                if (password == CreateMD5(haslopole.Text))
                {
                    Form7 f7 = new Form7();
                    UserId = Int32.Parse(Idlogin.Text);
                    f7.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Błędne dane logowania");
                }
                databaseConnection.Close();
            }catch
            (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            }

        private void button4_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.ShowDialog();
        }
        public static string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert the byte array to hexadecimal string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }
    }
}
