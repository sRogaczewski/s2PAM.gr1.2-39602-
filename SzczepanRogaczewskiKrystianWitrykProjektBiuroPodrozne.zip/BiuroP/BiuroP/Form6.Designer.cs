﻿namespace BiuroP
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.Imie = new System.Windows.Forms.TextBox();
            this.Nazwisko = new System.Windows.Forms.TextBox();
            this.Pesel = new System.Windows.Forms.TextBox();
            this.Miasto = new System.Windows.Forms.TextBox();
            this.Ulica = new System.Windows.Forms.TextBox();
            this.Numer_tel = new System.Windows.Forms.TextBox();
            this.Mail = new System.Windows.Forms.TextBox();
            this.Hasło = new System.Windows.Forms.TextBox();
            this.button_dodaj_kont = new System.Windows.Forms.Button();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(18, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 13);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "Imie";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Control;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(18, 49);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 13);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "Nazwisko";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.Control;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Location = new System.Drawing.Point(18, 78);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 13);
            this.textBox3.TabIndex = 2;
            this.textBox3.Text = "Pesel";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.Control;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Location = new System.Drawing.Point(18, 112);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 13);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "Miasto";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.Control;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Location = new System.Drawing.Point(18, 144);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 13);
            this.textBox5.TabIndex = 4;
            this.textBox5.Text = "Ulica";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.Control;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Location = new System.Drawing.Point(18, 179);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 13);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "Numer Telefonu";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.Control;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Location = new System.Drawing.Point(18, 219);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 13);
            this.textBox7.TabIndex = 6;
            this.textBox7.Text = "Mail";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.Control;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Location = new System.Drawing.Point(18, 251);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 13);
            this.textBox8.TabIndex = 7;
            this.textBox8.Text = "Hasło";
            // 
            // Imie
            // 
            this.Imie.Location = new System.Drawing.Point(124, 16);
            this.Imie.Name = "Imie";
            this.Imie.Size = new System.Drawing.Size(100, 20);
            this.Imie.TabIndex = 8;
            // 
            // Nazwisko
            // 
            this.Nazwisko.Location = new System.Drawing.Point(124, 49);
            this.Nazwisko.Name = "Nazwisko";
            this.Nazwisko.Size = new System.Drawing.Size(100, 20);
            this.Nazwisko.TabIndex = 9;
            // 
            // Pesel
            // 
            this.Pesel.Location = new System.Drawing.Point(124, 78);
            this.Pesel.Name = "Pesel";
            this.Pesel.Size = new System.Drawing.Size(100, 20);
            this.Pesel.TabIndex = 10;
            // 
            // Miasto
            // 
            this.Miasto.Location = new System.Drawing.Point(124, 112);
            this.Miasto.Name = "Miasto";
            this.Miasto.Size = new System.Drawing.Size(100, 20);
            this.Miasto.TabIndex = 11;
            // 
            // Ulica
            // 
            this.Ulica.Location = new System.Drawing.Point(124, 144);
            this.Ulica.Name = "Ulica";
            this.Ulica.Size = new System.Drawing.Size(100, 20);
            this.Ulica.TabIndex = 12;
            // 
            // Numer_tel
            // 
            this.Numer_tel.Location = new System.Drawing.Point(124, 176);
            this.Numer_tel.Name = "Numer_tel";
            this.Numer_tel.Size = new System.Drawing.Size(100, 20);
            this.Numer_tel.TabIndex = 13;
            // 
            // Mail
            // 
            this.Mail.Location = new System.Drawing.Point(124, 216);
            this.Mail.Name = "Mail";
            this.Mail.Size = new System.Drawing.Size(100, 20);
            this.Mail.TabIndex = 14;
            // 
            // Hasło
            // 
            this.Hasło.Location = new System.Drawing.Point(124, 251);
            this.Hasło.Name = "Hasło";
            this.Hasło.Size = new System.Drawing.Size(100, 20);
            this.Hasło.TabIndex = 15;
            // 
            // button_dodaj_kont
            // 
            this.button_dodaj_kont.Location = new System.Drawing.Point(193, 346);
            this.button_dodaj_kont.Name = "button_dodaj_kont";
            this.button_dodaj_kont.Size = new System.Drawing.Size(75, 24);
            this.button_dodaj_kont.TabIndex = 16;
            this.button_dodaj_kont.Text = "Dodaj konto";
            this.button_dodaj_kont.UseVisualStyleBackColor = true;
            this.button_dodaj_kont.Click += new System.EventHandler(this.button_dodaj_kont_Click);
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.SystemColors.Control;
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox17.Location = new System.Drawing.Point(193, 12);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 13);
            this.textBox17.TabIndex = 17;
            this.textBox17.Text = "Wprowadź dane";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.Imie);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.Hasło);
            this.groupBox1.Controls.Add(this.Nazwisko);
            this.groupBox1.Controls.Add(this.Mail);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.Numer_tel);
            this.groupBox1.Controls.Add(this.Pesel);
            this.groupBox1.Controls.Add(this.Ulica);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.Miasto);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Location = new System.Drawing.Point(43, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 283);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.button_dodaj_kont);
            this.Name = "Form6";
            this.Text = "Form6";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox Imie;
        private System.Windows.Forms.TextBox Nazwisko;
        private System.Windows.Forms.TextBox Pesel;
        private System.Windows.Forms.TextBox Miasto;
        private System.Windows.Forms.TextBox Ulica;
        private System.Windows.Forms.TextBox Numer_tel;
        private System.Windows.Forms.TextBox Mail;
        private System.Windows.Forms.TextBox Hasło;
        private System.Windows.Forms.Button button_dodaj_kont;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}