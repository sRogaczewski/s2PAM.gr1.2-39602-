﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace BiuroP
{
    public partial class Form7 : Form
    {
        static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=biuro_podrozne;";
        MySqlConnection databaseConnection = new MySqlConnection(connectionString);
        string ubezpieczeniaQuery = "SELECT * FROM  biuro_podrozne.ubezpieczenia";
        MySqlDataReader reader;
        public Form7()
        {
            InitializeComponent();
            ubezpieczeniaFill();
            WycieczkiFill();
            datep.MinDate = DateTime.Now.AddDays(1);
            datek.MinDate = DateTime.Now.AddDays(2);
            datep.MaxDate = DateTime.Now.AddDays(364);
            datek.MaxDate = DateTime.Now.AddDays(365);

        }


        private void button2_Click(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(UbezpieczenieId.Text)|| String.IsNullOrEmpty(Uczestnicy.Text)|| String.IsNullOrEmpty(IdWycieczka.Text))
                MessageBox.Show("Błędne dane");
            else   cena.Text= Obliczkoszt().ToString()+" zł";
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime datapoczatkowa = datep.Value;
            DateTime datakoncowa = datek.Value;
            TimeSpan t = datakoncowa.Subtract(datapoczatkowa);
            DateTime now = DateTime.Now;

            try
            {
                if (t.TotalDays >= 0 && int.Parse(Uczestnicy.Text) >= 1 && wycieczkafind() == true && ubezpieczeniafind() == true && String.IsNullOrEmpty(UbezpieczenieId.Text) == false && String.IsNullOrEmpty(Uczestnicy.Text) == false && String.IsNullOrEmpty(IdWycieczka.Text) == false)
                {

                    string insertQuery = "INSERT INTO biuro_podrozne.rezerwacja(Początek,Koniec,Id_ubezpieczenia,Id_klienta,Id_wycieczki,Koszt,Liczba_osób) VALUES('" + datep.Text + "','" + datek.Text + "'," + UbezpieczenieId.Text + "," + Form1.UserId + "," + IdWycieczka.Text + "," + Obliczkoszt() + "," + Uczestnicy.Text + ")";
                    databaseConnection.Open();
                    MySqlCommand command = new MySqlCommand(insertQuery, databaseConnection);


                    if (command.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("Zarezerwowano");
                    }
                    else
                    {
                        MessageBox.Show("Nie zarezerwowano");
                    }
                }
                else
                    MessageBox.Show("Niepoprawne dane");


                databaseConnection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        private void ubezpieczeniaFill()
        {
            MySqlCommand commandDatabase = new MySqlCommand(ubezpieczeniaQuery, databaseConnection);
            try
            {
                databaseConnection.Open();

                reader = commandDatabase.ExecuteReader();

                if (reader.HasRows)
                {
                    

                    while (reader.Read())
                    {

                        string[] row = { reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3) };
                        UbezpieczenieBox.Items.Add(row[0] + " " + row[2] + " " + row[3] + " " + row[1] );
                    }
                }
                databaseConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private bool ubezpieczeniafind()
        {
            string idU="";
            string compareQuery = "SELECT * FROM  biuro_podrozne.ubezpieczenia Where Id_ubezpieczenia=" + int.Parse(UbezpieczenieId.Text);
            MySqlCommand commandDatabase = new MySqlCommand(compareQuery, databaseConnection);

                databaseConnection.Open();

                reader = commandDatabase.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        idU = reader.GetString("Id_ubezpieczenia");
                    }
                }
            if (idU == UbezpieczenieId.Text)
            {
                databaseConnection.Close();
                return true;
            }
                databaseConnection.Close();
                return false;
        }
        private bool wycieczkafind()
        {
            string idW = "";
            string compareQuery = "SELECT * FROM  biuro_podrozne.wycieczki Where Id_wycieczki=" + int.Parse(IdWycieczka.Text);
            MySqlCommand commandDatabase = new MySqlCommand(compareQuery, databaseConnection);

            databaseConnection.Open();

            reader = commandDatabase.ExecuteReader();
                if (reader.Read())
                {
                    idW = reader.GetString("Id_wycieczki");
                }
           
            if (idW == IdWycieczka.Text)
            {
                databaseConnection.Close();
                return true;
             }
            databaseConnection.Close();
            return false;
        }

        private void WycieczkiFill()
        {
            string wycieczkiQuery = "SELECT * FROM biuro_podrozne.wycieczki";
            MySqlCommand commandDatabase = new MySqlCommand(wycieczkiQuery, databaseConnection);
            try
            {
                databaseConnection.Open();

                reader = commandDatabase.ExecuteReader();

                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        string[] row = { reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5) };
                        WycieczkaBox.Items.Add(row[0] + " " + row[1] + " " + row[2] + " " + row[5]+" "+row[3]);
                    }
                }
                databaseConnection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private int findcost()
        {
            int value = 0;
           MySqlDataReader mdr;
            string compareQuery = "Select * FROM biuro_podrozne.ubezpieczenia WHERE Id_ubezpieczenia=" + int.Parse(UbezpieczenieId.Text);
            databaseConnection.Open();
            MySqlCommand command = new MySqlCommand(compareQuery, databaseConnection);
            mdr = command.ExecuteReader();
            if (mdr.Read())
            {
                value = mdr.GetInt32("cena_ubezpieczenia");
   
            }
            databaseConnection.Close();
            return value;
        }
        private int findcostofvacation()
        {
            int value = 0;
            MySqlDataReader mdr1;
            string compareQuery = "Select * FROM biuro_podrozne.wycieczki WHERE 	Id_wycieczki=" + int.Parse(IdWycieczka.Text);
            databaseConnection.Open();
            MySqlCommand command = new MySqlCommand(compareQuery, databaseConnection);
            mdr1 = command.ExecuteReader();
            if (mdr1.Read())
            {
                value = mdr1.GetInt32("Cena");

            }
            databaseConnection.Close();
            return value;
        }
       private double Obliczkoszt()
        {
            double koszt = 0.0;
            DateTime datapoczatkowa = datep.Value;
            DateTime datakoncowa= datek.Value;
            TimeSpan t = datakoncowa.Subtract(datapoczatkowa);
            koszt =Int32.Parse(Uczestnicy.Text)*t.TotalDays*findcostofvacation()+findcost();
            return Math.Round(koszt, 2);
        }

        private void datep_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form8 f8 = new Form8();
            f8.ShowDialog();
        }
    }
}
