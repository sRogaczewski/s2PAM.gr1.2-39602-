﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace BiuroP
{
    public partial class Form4 : Form
    {

        static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=biuro_podrozne;";
        MySqlConnection databaseConnection = new MySqlConnection(connectionString);
        public Form4()
        {
            InitializeComponent();
            listBox1.SelectedItem = "1";
           
        }



        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string deleteQuery = "DELETE FROM  biuro_podrozne.hotel WHERE Id_hotelu = " + Id.Text;
                databaseConnection.Open();
                MySqlCommand command = new MySqlCommand(deleteQuery, databaseConnection);

                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Hotel usunięty");
                }
                else
                {
                    MessageBox.Show("Hotel nieusunięty");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            databaseConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (isNotEmpty() == true)
            {

                string insertQuery = "INSERT INTO biuro_podrozne.hotel(Nazwa_hotelu,Ilość_gwiazdek,Opis,Strona) VALUES('" + nazwa.Text + "','" + listBox1.SelectedItem.ToString()+ "','" + opis.Text + "','" + strona.Text + "')";
            databaseConnection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, databaseConnection);

            try
            {
                if (command.ExecuteNonQuery() == 1 && listBox1.SelectedItem!=null)
                {
                    MessageBox.Show("Hotel dodany");
                }
                else
                {
                    MessageBox.Show("Hotel niedodany");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            databaseConnection.Close();
        }
            else checkTextBox();
    }

        public void checkTextBox()
        {
          
            if (nazwa.Text == "") MessageBox.Show("Podaj nazwę hotelu");
            if (strona.Text == "") MessageBox.Show("Podaj stronę hotelu");
            if (opis.Text == "") MessageBox.Show("Podaj opis hotelu");

        }
        public bool isNotEmpty()
        {
            if (nazwa.Text == "") return false;
            if (strona.Text == "") return false;
            if (opis.Text == "") return false;


            return true;
        }


    }

}
