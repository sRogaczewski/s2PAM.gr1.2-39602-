﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace BiuroP
{
    public partial class Form2 : Form
    {
        static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=biuro_podrozne;";
        MySqlConnection databaseConnection = new MySqlConnection(connectionString);
        public Form2()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 fprzewodnik = new Form3(); //lvl admin
            fprzewodnik.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 fhotel= new Form4(); //lvl hotel
            fhotel.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 fhotel = new Form5(); //lvl wycieczka
            fhotel.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string deleteQuery = "DELETE FROM  biuro_podrozne.klienci WHERE Id = " + Idbox.Text;
                databaseConnection.Open();
                MySqlCommand command = new MySqlCommand(deleteQuery, databaseConnection);

                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Użytkownik usunięty");
                }
                else
                {
                    MessageBox.Show("Brak użtkownika o Id= "+Idbox.Text);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            databaseConnection.Close();
        }
    }
}
