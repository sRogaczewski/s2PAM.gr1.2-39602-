﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BiuroP
{
    public partial class Form3 : Form
    {
       static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=biuro_podrozne;";
        MySqlConnection databaseConnection = new MySqlConnection(connectionString);

        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (isNotEmpty() == true)
            {
                string insertQuery = "INSERT INTO biuro_podrozne.przewodnicy(Imie_przewodnika,Nazwisko_przewodnika,Telefon,Miejsce_zamieszkania,Ulica_zamieszkania) VALUES('" + imie.Text + "','" + nazwisko.Text + "'," + telefon.Text + ",'" + miejsce.Text + "','" + ulica.Text + "')";
            databaseConnection.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, databaseConnection);

            try
            {
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Data Inserted");
                }
                else
                {
                    MessageBox.Show("Data Not Inserted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            databaseConnection.Close();
        }
            else checkTextBox();
    }

        private void button2_Click(object sender, EventArgs e)
        {

         
                try
                {
                    string deleteQuery = "DELETE FROM biuro_podrozne.przewodnicy WHERE Id_przewodnika = " + Id.Text;
                    databaseConnection.Open();
                    MySqlCommand command = new MySqlCommand(deleteQuery, databaseConnection);

                    if (command.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("Przewodnik usunięty");
                    }
                    else
                    {
                        MessageBox.Show("Przewodnik nieusunięty");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                databaseConnection.Close();
            
        }
        public void checkTextBox()
        {
            if (imie.Text == "") MessageBox.Show("Podaj imię");
            if (nazwisko.Text == "") MessageBox.Show("Podaj Nazwisko");
            if (telefon.Text == "") MessageBox.Show("Podaj Numer telefonu");
            if (miejsce.Text == "") MessageBox.Show("Podaj Miejsce zamieszkania");
            if (ulica.Text == "") MessageBox.Show("Podaj Ulicę");


        }
        public bool isNotEmpty()
        {
            if (imie.Text == "") return false;
            if (nazwisko.Text == "") return false;
            if (telefon.Text == "") return false;
            if (miejsce.Text == "") return false;
            if (ulica.Text == "") return false;

            return true;
        }

    }
    }
    
