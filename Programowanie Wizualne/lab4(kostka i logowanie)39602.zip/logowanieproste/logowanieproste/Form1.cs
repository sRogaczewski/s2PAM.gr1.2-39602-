﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace logowanieproste
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.login1 = login.Text;
            f.password1 = password.Text;
            if ((f.login1 == "jan") && (f.password1 == "1234"))
            {
                Napis.Text = "";
            
                f.Show();
            }
            else if((f.login1 == "michal") && (f.password1 == "4321"))
            {
                f.Show();
                Napis.Text = "";
            }
            else
            {
                Napis.ForeColor = Color.Red;
                Napis.Text = "Błędne dane logowania";
            }
        }
    }
}
